#nullable disable

namespace RaceLog;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    private void InitializeComponent()
    {
        lblDriver = new Label();
        txtDriver = new TextBox();
        lblCar = new Label();
        cmbCar = new ComboBox();
        lblTrack = new Label();
        cmbTrack = new ComboBox();
        lblTime = new Label();
        txtTime = new TextBox();
        btnAdd = new Button();
        btnClear = new Button();
        lblResults = new Label();
        Results = new ListBox();
        btnDelete = new Button();
        lblStatus = new Label();
        SuspendLayout();
        // 
        // lblDriver
        // 
        lblDriver.AutoSize = true;
        lblDriver.Location = new Point(32, 36);
        lblDriver.Name = "lblDriver";
        lblDriver.Size = new Size(48, 19);
        lblDriver.TabIndex = 8;
        lblDriver.Text = "Пилот";
        // 
        // txtDriver
        // 
        txtDriver.Location = new Point(139, 36);
        txtDriver.Name = "txtDriver";
        txtDriver.Size = new Size(250, 25);
        txtDriver.TabIndex = 0;
        // 
        // lblCar
        // 
        lblCar.AutoSize = true;
        lblCar.Location = new Point(32, 79);
        lblCar.Name = "lblCar";
        lblCar.Size = new Size(87, 19);
        lblCar.TabIndex = 9;
        lblCar.Text = "Автомобиль";
        // 
        // cmbCar
        // 
        cmbCar.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbCar.FormattingEnabled = true;
        cmbCar.Items.AddRange(new object[] { "Street", "Sport", "Prototype" });
        cmbCar.Location = new Point(139, 79);
        cmbCar.Name = "cmbCar";
        cmbCar.Size = new Size(250, 25);
        cmbCar.TabIndex = 1;
        // 
        // lblTrack
        // 
        lblTrack.AutoSize = true;
        lblTrack.Location = new Point(32, 123);
        lblTrack.Name = "lblTrack";
        lblTrack.Size = new Size(50, 19);
        lblTrack.TabIndex = 10;
        lblTrack.Text = "Трасса";
        // 
        // cmbTrack
        // 
        cmbTrack.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbTrack.FormattingEnabled = true;
        cmbTrack.Items.AddRange(new object[] { "Учебный овал", "Городское кольцо", "Спринт" });
        cmbTrack.Location = new Point(139, 123);
        cmbTrack.Name = "cmbTrack";
        cmbTrack.Size = new Size(250, 25);
        cmbTrack.TabIndex = 2;
        // 
        // lblTime
        // 
        lblTime.AutoSize = true;
        lblTime.Location = new Point(32, 169);
        lblTime.Name = "lblTime";
        lblTime.Size = new Size(87, 19);
        lblTime.TabIndex = 11;
        lblTime.Text = "Время круга";
        // 
        // txtTime
        // 
        txtTime.Location = new Point(139, 169);
        txtTime.Name = "txtTime";
        txtTime.Size = new Size(250, 25);
        txtTime.TabIndex = 3;
        // 
        // btnAdd
        // 
        btnAdd.Location = new Point(139, 217);
        btnAdd.Name = "btnAdd";
        btnAdd.Size = new Size(112, 34);
        btnAdd.TabIndex = 4;
        btnAdd.Text = "Добавить";
        btnAdd.UseVisualStyleBackColor = true;
        btnAdd.Click += btnAdd_Click;
        // 
        // btnClear
        // 
        btnClear.Location = new Point(261, 217);
        btnClear.Name = "btnClear";
        btnClear.Size = new Size(128, 34);
        btnClear.TabIndex = 5;
        btnClear.Text = "Очистить поля";
        btnClear.UseVisualStyleBackColor = true;
        btnClear.Click += btnClear_Click;
        // 
        // lblResults
        // 
        lblResults.AutoSize = true;
        lblResults.Location = new Point(395, 10);
        lblResults.Name = "lblResults";
        lblResults.Size = new Size(80, 19);
        lblResults.TabIndex = 12;
        lblResults.Text = "Результаты";
        // 
        // Results
        // 
        Results.FormattingEnabled = true;
        Results.HorizontalScrollbar = true;
        Results.IntegralHeight = false;
        Results.Location = new Point(395, 36);
        Results.Name = "Results";
        Results.Size = new Size(336, 296);
        Results.TabIndex = 6;
        // 
        // btnDelete
        // 
        btnDelete.Location = new Point(395, 338);
        btnDelete.Name = "btnDelete";
        btnDelete.Size = new Size(204, 34);
        btnDelete.TabIndex = 7;
        btnDelete.Text = "Удалить выбранную строку";
        btnDelete.UseVisualStyleBackColor = true;
        btnDelete.Click += btnDelete_Click;
        // 
        // lblStatus
        // 
        lblStatus.Location = new Point(32, 327);
        lblStatus.Name = "lblStatus";
        lblStatus.Size = new Size(230, 45);
        lblStatus.TabIndex = 13;
        lblStatus.Text = "Введите имя пилота";
        // 
        // Form1
        // 
        AcceptButton = btnAdd;
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        ClientSize = new Size(755, 400);
        Controls.Add(lblDriver);
        Controls.Add(txtDriver);
        Controls.Add(lblCar);
        Controls.Add(cmbCar);
        Controls.Add(lblTrack);
        Controls.Add(cmbTrack);
        Controls.Add(lblTime);
        Controls.Add(txtTime);
        Controls.Add(btnAdd);
        Controls.Add(btnClear);
        Controls.Add(lblResults);
        Controls.Add(Results);
        Controls.Add(btnDelete);
        Controls.Add(lblStatus);
        Font = new Font("Segoe UI", 10F);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        Name = "Form1";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Журнал заездов";
        ResumeLayout(false);
        PerformLayout();
    }

    #endregion

    private Label lblDriver;
    private TextBox txtDriver;
    private Label lblCar;
    private ComboBox cmbCar;
    private Label lblTrack;
    private ComboBox cmbTrack;
    private Label lblTime;
    private TextBox txtTime;
    private Button btnAdd;
    private Button btnClear;
    private Label lblResults;
    private ListBox Results;
    private Button btnDelete;
    private Label lblStatus;
}
